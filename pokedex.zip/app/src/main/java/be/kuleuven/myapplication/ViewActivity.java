package be.kuleuven.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

import de.hdodenhof.circleimageview.CircleImageView;

public class ViewActivity extends AppCompatActivity {

    CircleImageView imageView;
    TextView Name,Number;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);
        imageView=findViewById(R.id.profileImage);
        Name=findViewById(R.id.textView3);
        Number = findViewById(R.id.number);

        int image = getIntent().getIntExtra("image", 1);
        String name = getIntent().getStringExtra("name");
        String number = getIntent().getStringExtra("number");

        imageView.setImageResource(image);
        Name.setText(name);
        Number.setText(number);

    }
}