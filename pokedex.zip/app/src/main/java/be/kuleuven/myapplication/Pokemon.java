package be.kuleuven.myapplication;

import java.util.ArrayList;
import java.util.List;

public class Pokemon {

    private String name;
    private String id;
    private String type;
    public String xp;
    private  String height;
    private String weight;
    private String stat0,stat1,stat2,stat3,stat4,stat5;
    private String ability;
    private String generation;
    private String strain;
    List<String> sprites = new ArrayList<>();
    private int image;
    private String url;

    public Pokemon(){}

    public Pokemon(String name, String image){
        this.name=name;
        url=image;
    }

    public Pokemon(String name, String id, int image) {
        this.name = name;
        this.id = id;
        this.xp = xp;
        this.image = image;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setXp(String xp) {
        this.xp = xp;
    }

    public String getXp() {
        return xp;
    }

    public String getNumber() {
        return id;
    }

    public String getType() {
        return type;
    }

    public String getHeight() {
        return height;
    }

    public String getWeight() {
        return weight;
    }

    public String getStat0() {
        return stat0;
    }

    public String getStat1() {
        return stat1;
    }

    public String getStat2() {
        return stat2;
    }

    public String getStat3() {
        return stat3;
    }

    public String getStat4() {
        return stat4;
    }

    public String getStat5() {
        return stat5;
    }



    public String getAbility() {
        return ability;
    }

    public String getGeneration() {
         return generation;
    }

    public String getStrain() {
        return strain;
    }

    public List<String> getSprites() {
        return sprites;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setNumber(String number) {
        this.id = number;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public void setStat0(String stat0) {
        this.stat0 = stat0;
    }

    public void setStat1(String stat1) {
        this.stat1 = stat1;
    }

    public void setStat2(String stat2) {
        this.stat2 = stat2;
    }

    public void setStat3(String stat3) {
        this.stat3 = stat3;
    }

    public void setStat4(String stat4) {
        this.stat4 = stat4;
    }

    public void setStat5(String stat5) {
        this.stat5 = stat5;
    }

    public void setAbility(String ability) {
        this.ability = ability;
    }

    public void setGeneration(String generation) {
        this.generation = generation;
    }

    public void setStrain(String strain) {
        this.strain = strain;
    }

    public void setSprites(List<String> sprites) {
        this.sprites = sprites;
    }
}
