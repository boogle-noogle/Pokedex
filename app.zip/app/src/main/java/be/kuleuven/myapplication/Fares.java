package be.kuleuven.myapplication;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Fares {
    RequestQueue requestQueue;
    List<Pokemon> list = new ArrayList<>();
    public List<Pokemon> getList(){
        return list;
    }
    public void sendRequest() {
        //for (int j = 1; j < 20; j++) {
            String requestURL2 = "https://pokeapi.co/api/v2/pokemon?limit=151";


            JsonObjectRequest jsonArrayRequest = new JsonObjectRequest(Request.Method.GET, requestURL2, null, new Response.Listener<JSONObject>() {

                @Override
                public void onResponse(JSONObject response) {

                    for (int i = 0; i < response.length(); i++) {

                        Pokemon pokemon = new Pokemon();

                        try {
                            JSONObject jsonObject = response.getJSONObject(String.valueOf(i));

                            String xpString = "";
                            String nameString = "";
                            String heightString = "";
                            String idString = "";
                            String weightString = "";


                            xpString += jsonObject.getString("base_experience");
                            nameString += jsonObject.getString("name");
                            heightString += jsonObject.getString("height");
                            idString += jsonObject.getString("id");
                            weightString += jsonObject.getString("weight");


                            pokemon.setXp(xpString);
                            pokemon.setName(nameString);
                            pokemon.setHeight(heightString);
                            pokemon.setNumber(idString);
                            pokemon.setWeight(weightString);


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        list.add(pokemon);

                    }
                    //recyclerView.setAdapter(adapter);
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    error.printStackTrace();
                    //Log.i("Volley Error: ", error);
                }
            });


            //requestQueue.add(jsonArrayRequest);

        //}

    }


}
